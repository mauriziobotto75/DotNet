﻿using  System.Collections.Generic;
using   System.ComponentModel;
using   System.Data;
using   System.Data.SqlClient;
using   System.Data.OleDb;
using  System.Drawing;
using  System.Linq;
using   System.Text;
using   System.Windows.Forms;

 
 
public partial class frmGestioneSquadre : Form

{

        Public frmGestioneSquadre()
        {
            InitializeComponent();
        }

        private void btnPrimo_Click(object sender, EventArgs e)
   {
            squadreBindingSource.MoveFirst();

  }


        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'campionatoDataSet.Squadre' table. You can move, or remove it, as needed.
            this.squadreTableAdapter.Fill(this.campionatoDataSet.Squadre);
        }



        private void btnUltimo_Click(object sender, EventArgs e)
        {
            squadreBindingSource.MoveLast();

        }


        private void btnPrecedente_Click(object sender, EventArgs e)
        {
            squadreBindingSource.MovePrevious();
            if (squadreBindingSource.Count < 0)

                squadreBindingSource.Position = 0;
        }


        private void btnSuccessivo_Click(object sender, EventArgs e)
    {
            squadreBindingSource.MoveNext();
            if (squadreBindingSource.Position > (squadreBindingSource.Count - 1))
                squadreBindingSource.Position = squadreBindingSource.Count - 1;
   }


        private void Form1_Load(object sender, EventArgs e)
   {
            // TODO: This line of code loads data into the 'campionatoDataSet.Squadre' table. You can move, or remove it, as needed.
             

            this.squadreTableAdapter.Fill(this.campionatoDataSet1.Squadre);
         string  stringaConnessione; 

            stringaConnessione = "Provider.Microsoft.Jet.Oledb.4.0; password = 'admin'; data source = '@C:\EsercizioISCS\Campionato.mdb'";
  OleDbConnection con;
        OleDbCommand letturaDati;
        OleDbDataReader scorriDati;
        int diffReti;
        datagridviewTextBoxColumn differenzaReti;
            con = new OleDbConnection(stringaConnessione);
            con.Open();
            letturaDati = new OleDbCommand("Select * from Squadre", con);
            scorriDati = letturaDati.ExecuteReader(CommandBehavior.SingleResult);







            do 
            {
                int valore1 = Int32.parse(scorriDati.GetValue("GolFatti"));
                int valore2 = Int32.parse(scorriDati.GetValue("GolSubiti"));
                diffReti =  valore1 - valore2; 

                scorriDati.Item("DifferenzaReti") = diffReti;
                differenzaReti = diffReti;


            } While (scorriDati.Read );
            

 this.campionatoDataSet.Squadre = scorriDati;
 this.squadreTableAdapter.Update(this.campionatoDataSet.Squadre);



            con.Close();  
        }