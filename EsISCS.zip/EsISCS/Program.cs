﻿Imports System;
Imports System.Collections.Generic;
Imports System.Linq;
Imports System.Windows.Forms;

namespace EsISCS
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        
            Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(false)
            Application.Run(new frmGestioneSquadre())
        
    

