﻿namespace EsISCS
{
    partial class frmGestioneSquadre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNomeSquadra = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtGiocate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtVinte = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPareggiate = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPerse = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtGolFatti = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtGolSubiti = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDifferenzaReti = new System.Windows.Forms.TextBox();
            this.btnPrimo = new System.Windows.Forms.Button();
            this.btnPrecedente = new System.Windows.Forms.Button();
            this.btnSuccessivo = new System.Windows.Forms.Button();
            this.btnUltimo = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome Squadra:";
            // 
            // txtNomeSquadra
            // 
            this.txtNomeSquadra.Location = new System.Drawing.Point(118, 25);
            this.txtNomeSquadra.Name = "txtNomeSquadra";
            this.txtNomeSquadra.Size = new System.Drawing.Size(205, 20);
            this.txtNomeSquadra.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "Giocate:\r\n\r\n";
            // 
            // txtGiocate
            // 
            this.txtGiocate.Location = new System.Drawing.Point(118, 56);
            this.txtGiocate.Name = "txtGiocate";
            this.txtGiocate.Size = new System.Drawing.Size(51, 20);
            this.txtGiocate.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Vinte:";
            // 
            // txtVinte
            // 
            this.txtVinte.Location = new System.Drawing.Point(118, 85);
            this.txtVinte.Name = "txtVinte";
            this.txtVinte.Size = new System.Drawing.Size(51, 20);
            this.txtVinte.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Pareggiate:";
            // 
            // txtPareggiate
            // 
            this.txtPareggiate.Location = new System.Drawing.Point(118, 120);
            this.txtPareggiate.Name = "txtPareggiate";
            this.txtPareggiate.Size = new System.Drawing.Size(51, 20);
            this.txtPareggiate.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Perse:";
            // 
            // txtPerse
            // 
            this.txtPerse.Location = new System.Drawing.Point(118, 155);
            this.txtPerse.Name = "txtPerse";
            this.txtPerse.Size = new System.Drawing.Size(51, 20);
            this.txtPerse.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Gol Fatti:";
            // 
            // txtGolFatti
            // 
            this.txtGolFatti.Location = new System.Drawing.Point(118, 187);
            this.txtGolFatti.Name = "txtGolFatti";
            this.txtGolFatti.Size = new System.Drawing.Size(51, 20);
            this.txtGolFatti.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Gol Subiti:";
            // 
            // txtGolSubiti
            // 
            this.txtGolSubiti.Location = new System.Drawing.Point(118, 220);
            this.txtGolSubiti.Name = "txtGolSubiti";
            this.txtGolSubiti.Size = new System.Drawing.Size(51, 20);
            this.txtGolSubiti.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(33, 262);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Differenza Reti:";
            // 
            // txtDifferenzaReti
            // 
            this.txtDifferenzaReti.Location = new System.Drawing.Point(118, 259);
            this.txtDifferenzaReti.Name = "txtDifferenzaReti";
            this.txtDifferenzaReti.Size = new System.Drawing.Size(51, 20);
            this.txtDifferenzaReti.TabIndex = 15;
            // 
            // btnPrimo
            // 
            this.btnPrimo.Location = new System.Drawing.Point(51, 318);
            this.btnPrimo.Name = "btnPrimo";
            this.btnPrimo.Size = new System.Drawing.Size(84, 33);
            this.btnPrimo.TabIndex = 16;
            this.btnPrimo.Text = "Primo";
            this.btnPrimo.UseVisualStyleBackColor = true;
            this.btnPrimo.Click += new System.EventHandler(this.btnPrimo_Click);
            // 
            // btnPrecedente
            // 
            this.btnPrecedente.Location = new System.Drawing.Point(152, 318);
            this.btnPrecedente.Name = "btnPrecedente";
            this.btnPrecedente.Size = new System.Drawing.Size(84, 33);
            this.btnPrecedente.TabIndex = 17;
            this.btnPrecedente.Text = "Precedente";
            this.btnPrecedente.UseVisualStyleBackColor = true;
            this.btnPrecedente.Click += new System.EventHandler(this.btnPrecedente_Click);
            // 
            // btnSuccessivo
            // 
            this.btnSuccessivo.Location = new System.Drawing.Point(252, 318);
            this.btnSuccessivo.Name = "btnSuccessivo";
            this.btnSuccessivo.Size = new System.Drawing.Size(84, 33);
            this.btnSuccessivo.TabIndex = 18;
            this.btnSuccessivo.Text = "Successivo\r\n";
            this.btnSuccessivo.UseVisualStyleBackColor = true;
            // 
            // btnUltimo
            // 
            this.btnUltimo.Location = new System.Drawing.Point(356, 318);
            this.btnUltimo.Name = "btnUltimo";
            this.btnUltimo.Size = new System.Drawing.Size(84, 33);
            this.btnUltimo.TabIndex = 19;
            this.btnUltimo.Text = "Ultimo";
            this.btnUltimo.UseVisualStyleBackColor = true;
            this.btnUltimo.Click += new System.EventHandler(this.btnUltimo_Click);
            // 
            // frmGestioneSquadre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 363);
            this.Controls.Add(this.btnUltimo);
            this.Controls.Add(this.btnSuccessivo);
            this.Controls.Add(this.btnPrecedente);
            this.Controls.Add(this.btnPrimo);
            this.Controls.Add(this.txtDifferenzaReti);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtGolSubiti);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtGolFatti);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtPerse);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPareggiate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtVinte);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtGiocate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNomeSquadra);
            this.Controls.Add(this.label1);
            this.Name = "frmGestioneSquadre";
            this.Text = "Classifica campionato Inglese";
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNomeSquadra;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtGiocate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtVinte;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPareggiate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPerse;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtGolFatti;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtGolSubiti;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDifferenzaReti;
        private System.Windows.Forms.Button btnPrimo;
        private System.Windows.Forms.Button btnPrecedente;
        private System.Windows.Forms.Button btnSuccessivo;
        private System.Windows.Forms.Button btnUltimo;
        private System.Windows.Forms.BindingSource bindingSource1;
    }
}

