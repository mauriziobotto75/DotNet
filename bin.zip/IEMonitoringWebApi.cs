﻿namespace Capgemini.Invent.DeliveryPulse.Intranet.Job.MasterDataSync
{
    internal class IEMonitoringWebApi
    {
    }
}