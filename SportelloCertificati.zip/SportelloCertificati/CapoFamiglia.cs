namespace SportelloCertificati
{
    public class CapoFamiglia
    {
        public int CodCapoFamiglia { get; set; }
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public string Indirizzo { get; set; }
        public string TelFisso { get; set; }
        public string TelCellulare { get; set; }
    }
}
