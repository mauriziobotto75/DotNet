using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;
using PdfSharp.Pdf;
using PdfSharp.Drawing;

namespace SportelloCertificati
{
    public partial class FormMain : Form
    {
        private List<CapoFamiglia> famiglie = new List<CapoFamiglia>();
        private List<Operazione> operazioni = new List<Operazione>();

        public FormMain()
        {
            InitializeComponent();
            InizializzaDatabase();
        }

        private void InizializzaDatabase()
        {
            famiglie.Add(new CapoFamiglia
            {
                CodCapoFamiglia = 12345,
                Nome = "Mario",
                Cognome = "Rossi",
                Indirizzo = "Via Roma 10",
                TelFisso = "0111234567",
                TelCellulare = "3331234567"
            });

            operazioni.Add(new Operazione { CodOperazione = 1, DesOperazione = "Certificato di nascita", CostoOperazione = 15.00f });
            operazioni.Add(new Operazione { CodOperazione = 2, DesOperazione = "Stato di famiglia", CostoOperazione = 16.90f });
            operazioni.Add(new Operazione { CodOperazione = 3, DesOperazione = "Certificato di residenza", CostoOperazione = 18.00f });
            operazioni.Add(new Operazione { CodOperazione = 4, DesOperazione = "Certificato di morte", CostoOperazione = 10.00f });
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtCodice.Text, out int codice))
            {
                var utente = famiglie.Find(f => f.CodCapoFamiglia == codice);
                if (utente != null)
                {
                    pnlMenu.Visible = true;
                    lblBenvenuto.Text = $"Benvenuto {utente.Nome} {utente.Cognome}";
                }
                else
                {
                    MessageBox.Show("Codice non trovato.");
                }
            }
            else
            {
                MessageBox.Show("Inserire un codice numerico valido.");
            }
        }

        private void SelezionaOperazione(int codice)
        {
            var op = operazioni.Find(o => o.CodOperazione == codice);
            if (op != null)
            {
                lblCertificato.Text = $"Certificato: {op.DesOperazione}";
                lblCosto.Text = $"Costo: {op.CostoOperazione} €";
                SalvaSuFile(op);
                SalvaSuDatabase(op);
                GeneraPDF(op);
                StampaCertificato(op);
            }
        }

        private void SalvaSuFile(Operazione op)
        {
            File.WriteAllText("certificato.txt", $"{op.DesOperazione} - Costo: {op.CostoOperazione} €");
        }

        private void SalvaSuDatabase(Operazione op)
        {
            string connStr = "Server=localhost;Database=CertificatiDB;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "INSERT INTO OperazioniLog (Descrizione, Costo) VALUES (@desc, @costo)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@desc", op.DesOperazione);
                    cmd.Parameters.AddWithValue("@costo", op.CostoOperazione);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void GeneraPDF(Operazione op)
        {
            PdfDocument document = new PdfDocument();
            document.Info.Title = "Certificato";
            PdfPage page = document.AddPage();
            XGraphics gfx = XGraphics.FromPdfPage(page);
            XFont font = new XFont("Verdana", 20, XFontStyle.Bold);
            gfx.DrawString($"Certificato: {op.DesOperazione}", font, XBrushes.Black, new XRect(0, 0, page.Width, page.Height / 2), XStringFormats.Center);
            gfx.DrawString($"Costo: {op.CostoOperazione} €", font, XBrushes.Black, new XRect(0, page.Height / 2, page.Width, page.Height / 2), XStringFormats.Center);
            document.Save("certificato.pdf");
        }

        private void StampaCertificato(Operazione op)
        {
            PrintDialog pd = new PrintDialog();
            if (pd.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter("certificato_print.txt");
                sw.WriteLine($"Certificato: {op.DesOperazione}");
                sw.WriteLine($"Costo: {op.CostoOperazione} €");
                sw.Close();
            }
        }

        private void btnF1_Click(object sender, EventArgs e) => SelezionaOperazione(1);
        private void btnF2_Click(object sender, EventArgs e) => SelezionaOperazione(2);
        private void btnF3_Click(object sender, EventArgs e) => SelezionaOperazione(3);
        private void btnF4_Click(object sender, EventArgs e) => SelezionaOperazione(4);
        private void btnF5_Click(object sender, EventArgs e) => SelezionaOperazione(2);
    }
}
