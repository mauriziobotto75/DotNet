namespace SportelloCertificati
{
    public class Operazione
    {
        public int CodOperazione { get; set; }
        public string DesOperazione { get; set; }
        public float CostoOperazione { get; set; }
    }
}
